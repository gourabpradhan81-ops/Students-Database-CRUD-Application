import os
import tempfile

_db = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["STUDENTS_DB"] = _db

import pytest
from fastapi.testclient import TestClient

from app.main import app

GOOD = {"name": "Test User", "date_of_birth": "2004-05-10", "email": "t@example.com", "course": "Python"}


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_full_crud_flow(client):
    r = client.post("/students", json=GOOD)
    assert r.status_code == 201
    sid = r.json()["id"]

    assert client.get(f"/students/{sid}").json()["name"] == "Test User"
    assert len(client.get("/students").json()) == 1
    assert len(client.get("/students?course=python").json()) == 1
    assert client.get("/students?born_after=2010-01-01").json() == []

    r = client.patch(f"/students/{sid}", json={"course": "Data Science"})
    assert r.status_code == 200 and r.json()["course"] == "Data Science"

    r = client.put(f"/students/{sid}", json={**GOOD, "name": "Renamed User"})
    assert r.json()["name"] == "Renamed User"

    assert client.delete(f"/students/{sid}").status_code == 204
    assert client.get(f"/students/{sid}").status_code == 404


def test_validation_and_errors(client):
    assert client.post("/students", json={"name": "A", "date_of_birth": "2004-01-01"}).status_code == 422
    assert client.post("/students", json={**GOOD, "date_of_birth": "2999-01-01"}).status_code == 422
    assert client.post("/students", json={**GOOD, "email": "not-an-email"}).status_code == 422
    assert client.post("/students", json={"name": "No Contact", "date_of_birth": "2004-01-01"}).status_code == 422
    assert client.get("/students/9999").status_code == 404
    assert client.delete("/students/9999").status_code == 404
    assert client.patch("/students/9999", json={"name": "Nobody"}).status_code == 404


def test_duplicate_email(client):
    client.post("/students", json={**GOOD, "email": "dup@example.com"})
    assert client.post("/students", json={**GOOD, "email": "dup@example.com"}).status_code == 409
