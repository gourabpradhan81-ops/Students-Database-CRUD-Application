import sqlite3
from contextlib import asynccontextmanager
from datetime import date
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Query, Response

from . import crud
from .ai import router as ai_router
from .database import init_db
from .schemas import StudentCreate, StudentOut, StudentUpdate


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Students Database CRUD API", version="1.0.0", lifespan=lifespan)
app.include_router(ai_router)


def _not_found(student_id: int):
    return HTTPException(status_code=404, detail=f"Student with id {student_id} not found")


def _duplicate():
    return HTTPException(status_code=409, detail="A student with this email already exists")


@app.get("/", tags=["Health"])
def root():
    return {"message": "Students API is running. Open /docs for the interactive docs."}


@app.post("/students", response_model=StudentOut, status_code=201, tags=["Students"])
def create_student(student: StudentCreate):
    try:
        return crud.create(student.model_dump(mode="json"))
    except sqlite3.IntegrityError:
        raise _duplicate()


@app.get("/students", response_model=List[StudentOut], tags=["Students"])
def list_students(
    name: Optional[str] = Query(None, description="Partial name match"),
    course: Optional[str] = Query(None, description="Partial course match"),
    born_after: Optional[date] = Query(None, description="DOB on/after (YYYY-MM-DD)"),
    born_before: Optional[date] = Query(None, description="DOB on/before (YYYY-MM-DD)"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=500),
):
    return crud.list_students(name, course, born_after, born_before, skip, limit)


@app.get("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def get_student(student_id: int):
    student = crud.get(student_id)
    if not student:
        raise _not_found(student_id)
    return student


@app.put("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def replace_student(student_id: int, student: StudentCreate):
    """Full update: send every field."""
    try:
        updated = crud.update(student_id, student.model_dump(mode="json"))
    except sqlite3.IntegrityError:
        raise _duplicate()
    if not updated:
        raise _not_found(student_id)
    return updated


@app.patch("/students/{student_id}", response_model=StudentOut, tags=["Students"])
def patch_student(student_id: int, changes: StudentUpdate):
    """Partial update: send only the fields you want to change."""
    existing = crud.get(student_id)
    if not existing:
        raise _not_found(student_id)
    data = changes.model_dump(mode="json", exclude_unset=True)
    merged = {**existing, **data}
    if not (merged.get("email") or merged.get("phone")):
        raise HTTPException(status_code=422, detail="A student must keep at least one contact (email or phone)")
    try:
        return crud.update(student_id, data)
    except sqlite3.IntegrityError:
        raise _duplicate()


@app.delete("/students/{student_id}", status_code=204, tags=["Students"])
def delete_student(student_id: int):
    if not crud.delete(student_id):
        raise _not_found(student_id)
    return Response(status_code=204)
