"""All SQL lives here. Every query is parameterised (no SQL injection)."""
from typing import Optional

from .database import get_conn

COLUMNS = ["name", "date_of_birth", "email", "phone", "course", "address", "enrollment_date"]


def _where(name=None, course=None, born_after=None, born_before=None):
    clauses, params = [], []
    if name:
        clauses.append("name LIKE ?")
        params.append(f"%{name}%")
    if course:
        clauses.append("course LIKE ?")
        params.append(f"%{course}%")
    if born_after:
        clauses.append("date_of_birth >= ?")
        params.append(str(born_after))
    if born_before:
        clauses.append("date_of_birth <= ?")
        params.append(str(born_before))
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


def create(data: dict) -> dict:
    values = [data.get(c) for c in COLUMNS]
    sql = f"INSERT INTO students ({', '.join(COLUMNS)}) VALUES ({', '.join('?' * len(COLUMNS))})"
    with get_conn() as conn:
        new_id = conn.execute(sql, values).lastrowid
        return dict(conn.execute("SELECT * FROM students WHERE id = ?", (new_id,)).fetchone())


def get(student_id: int) -> Optional[dict]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        return dict(row) if row else None


def list_students(name=None, course=None, born_after=None, born_before=None, skip=0, limit=100):
    where, params = _where(name, course, born_after, born_before)
    sql = f"SELECT * FROM students{where} ORDER BY id LIMIT ? OFFSET ?"
    with get_conn() as conn:
        return [dict(r) for r in conn.execute(sql, params + [limit, skip]).fetchall()]


def count(name=None, course=None, born_after=None, born_before=None) -> int:
    where, params = _where(name, course, born_after, born_before)
    with get_conn() as conn:
        return conn.execute(f"SELECT COUNT(*) FROM students{where}", params).fetchone()[0]


def distinct_courses() -> list:
    with get_conn() as conn:
        rows = conn.execute("SELECT DISTINCT course FROM students WHERE course IS NOT NULL").fetchall()
        return [r[0] for r in rows]


def update(student_id: int, data: dict) -> Optional[dict]:
    fields = {k: v for k, v in data.items() if k in COLUMNS}  # whitelist
    with get_conn() as conn:
        if fields:
            assignments = ", ".join(f"{k} = ?" for k in fields)
            cur = conn.execute(
                f"UPDATE students SET {assignments} WHERE id = ?", list(fields.values()) + [student_id]
            )
            if cur.rowcount == 0:
                return None
        row = conn.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        return dict(row) if row else None


def delete(student_id: int) -> bool:
    with get_conn() as conn:
        return conn.execute("DELETE FROM students WHERE id = ?", (student_id,)).rowcount > 0
