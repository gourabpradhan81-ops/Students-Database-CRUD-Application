from datetime import date
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

PHONE_PATTERN = r"^\+?[0-9\s\-]{7,15}$"


def _dob_check(v):
    if v is not None and v >= date.today():
        raise ValueError("date_of_birth must be in the past")
    return v


class StudentCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    date_of_birth: date
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, pattern=PHONE_PATTERN)
    course: Optional[str] = Field(None, max_length=100)
    address: Optional[str] = Field(None, max_length=255)
    enrollment_date: Optional[date] = None

    _dob = field_validator("date_of_birth")(_dob_check)

    @model_validator(mode="after")
    def need_contact(self):
        if not (self.email or self.phone):
            raise ValueError("Provide at least one contact: email or phone")
        return self


class StudentUpdate(BaseModel):
    """All fields optional - used for PATCH (partial update)."""
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    date_of_birth: Optional[date] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, pattern=PHONE_PATTERN)
    course: Optional[str] = Field(None, max_length=100)
    address: Optional[str] = Field(None, max_length=255)
    enrollment_date: Optional[date] = None

    _dob = field_validator("date_of_birth")(_dob_check)


class StudentOut(BaseModel):
    id: int
    name: str
    date_of_birth: date
    email: Optional[str] = None
    phone: Optional[str] = None
    course: Optional[str] = None
    address: Optional[str] = None
    enrollment_date: Optional[date] = None
