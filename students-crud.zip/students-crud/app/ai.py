"""OPTIONAL bonus: ask questions in plain English, answered by a local Ollama model.

Safety design: the model NEVER writes or runs SQL. Our code detects simple filters
(birth year, course), fetches matching rows with parameterised queries, and passes
only those rows to the model as context.
"""
import os
import re

import requests
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from . import crud

router = APIRouter(prefix="/ai", tags=["AI (optional)"])

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:1b")
MAX_ROWS = 50


class Question(BaseModel):
    question: str = Field(min_length=3, max_length=300, examples=["List students born after 2005"])


def detect_filters(question: str) -> dict:
    q = question.lower()
    filters = {}
    m = re.search(r"born\s+(after|before|in)\s+(\d{4})", q)
    if m:
        kind, year = m.group(1), int(m.group(2))
        if kind == "after":
            filters["born_after"] = f"{year + 1}-01-01"
        elif kind == "before":
            filters["born_before"] = f"{year - 1}-12-31"
        else:
            filters["born_after"], filters["born_before"] = f"{year}-01-01", f"{year}-12-31"
    for course in crud.distinct_courses():
        if course.lower() in q:
            filters["course"] = course
            break
    return filters


@router.post("/ask")
def ask(body: Question):
    filters = detect_filters(body.question)
    total = crud.count()
    matched_count = crud.count(**filters)
    rows = crud.list_students(**filters, limit=MAX_ROWS)

    lines = [
        f"{r['id']}: {r['name']}, born {r['date_of_birth']}, course {r['course'] or 'N/A'}"
        for r in rows
    ]
    context = (
        f"Total students in database: {total}\n"
        f"Students matching the question's filters: {matched_count}\n"
        f"Matching records (max {MAX_ROWS}):\n" + ("\n".join(lines) or "none")
    )
    prompt = (
        "You answer questions about a student database. Use ONLY the data below. "
        "If the data does not contain the answer, say you don't know.\n\n"
        f"DATA:\n{context}\n\nQUESTION: {body.question}\nANSWER:"
    )

    try:
        resp = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": OLLAMA_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "options": {"temperature": 0},
            },
            timeout=120,
        )
        resp.raise_for_status()
        answer = resp.json()["message"]["content"].strip()
    except requests.RequestException:
        raise HTTPException(
            status_code=503,
            detail=f"Ollama is not reachable. Start it and run: ollama pull {OLLAMA_MODEL}",
        )
    return {"question": body.question, "answer": answer, "filters_used": filters, "records_used": len(rows)}
