"""Load DUMMY data:  python -m app.seed"""
from . import crud
from .database import init_db

DUMMY = [
    ("Aarav Sharma", "2004-03-15", "aarav@example.com", "9876543210", "Python Backend"),
    ("Diya Patel", "2005-07-21", "diya@example.com", None, "Data Science"),
    ("Rohan Das", "2006-01-09", "rohan@example.com", "9123456780", "Python Backend"),
    ("Ananya Singh", "2003-11-30", None, "9988776655", "Web Development"),
    ("Kabir Mehta", "2007-05-02", "kabir@example.com", None, "Data Science"),
    ("Isha Nair", "2005-12-25", "isha@example.com", "9012345678", "Web Development"),
]

if __name__ == "__main__":
    init_db()
    if crud.count():
        print("Database already has data - skipping seed.")
    else:
        for name, dob, email, phone, course in DUMMY:
            crud.create({"name": name, "date_of_birth": dob, "email": email, "phone": phone,
                         "course": course, "enrollment_date": "2024-08-01"})
        print(f"Inserted {len(DUMMY)} dummy students.")
